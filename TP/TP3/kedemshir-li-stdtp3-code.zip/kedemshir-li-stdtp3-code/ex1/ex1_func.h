typedef unsigned long int TNumber;

typedef struct TPerson TPerson;
struct TPerson {
    char * firstname;
    char * lastname;
    char * addr;
    char * bday;
    char * sex;
    TNumber number;
    TPerson * left;
    TPerson * right;
};

typedef struct TTree TTree;
struct TTree {
    TPerson * root;
};

/**
 * @brief Initialises Tree with one root node.
 * @param TPerson* pointer to the person which will be the root of the tree.
 * @return TTree* the initialised tree via a call to malloc(). Don't forget to free !
 */
TTree * init(TPerson*);

/**
 * @brief Prints a TPerson to stdout.
 * @param TPerson* person to be printed.
 */
void print(TPerson*);

/**
 * @brief Converts a phone string number of format "123-456-7891" to an unsigned integer 1234567891.
 * @param number the string representing the number (e.g. "123-456-7891").
 * @return unsigned int the value (e.g. 1234567891).
 */
TNumber convert(char * number);

/**
 * @brief Creates a person. Non initialised pointers are set to NULL.
 * @param first is the person's first name
 * @param last is the person's last name
 * @param addr is the person's address
 * @param bday is the string representing a person's birthday
 * @param sex is the person's sex (either 'Male' or 'Female')
 * @param num is the person's telephone number as type TNumber
 * @return TPerson by reference. 
 * @warning this function does a malloc() ! Don't forget to free() after you're done. 
 */
TPerson * create(char * first, char * last, char * addr, char * bday, char * sex, TNumber num);

/**
 * @brief Inserts a person into the tree.  Takes O(log(N)) operations.
 * @param TPerson* the person to be inserted into the tree.
 * @param TTree* the tree into which the person will be inserted.
 * @warning if a person in the tree has the same number as the person being inserted, this function does nothing. 
 */
void insert(TPerson*, TTree*);

/**
 * @brief Finds and returns a reference to a person from the tree.
 * @param TTree* the tree
 * @param number the phone_number of the person.
 * @return TPerson* the person who has that phone number.
 */
TPerson * find(TTree *, char * number);

/**
 * @brief Creates a tree and populates it with TPersons
 * from a .csv ascii file whose columns are the same 
 * format as TPerson.
 * 
 * @param path relative path to the file. 
 * @return TTree* a tree reference containing all values.
 */
TTree * populate(char * path);

/**
 * @brief Parses an ascii csv line.
 * @param line a string containing 6 comma seperated values. 
 * for example char * str = "orwell, 1984, distopia, hello, world, unix" 
 * @param size the number of values (or commas) found in the line will be stored into this variable.
 * @return char** value where value[i] is the word at column i of the csv line.
 * char** points to a buffer of n_cols * sizeof(char *).
 * size is the variable that'll contain the size of the char**
 * pointer returned by the function, e.g. n_cols.
 * This function does a malloc, free appropriately !
 */
char ** parse_csv(char * line, size_t * size);