#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "ex1_func.h"

int main() {
    TNumber a = convert("999-999-9999");
    assert(a == 9999999999);

    TPerson * pers = create(
        "John", 
        "Doe", 
        "Rte de Drize 7 Battelle", 
        "18.05.1995", 
        "Male", 
        convert("123-456-7891")
    );
    assert(strcmp(pers->lastname, "Doe") == 0);
    assert(pers->number == 1234567891);

    print(pers);  // Shows a person.

    size_t size;

    // attention, strtok modifies its first parameter! It must be a buffer pointed by malloc.
    char * non_mutable_string_literal = "john,doe,margaret,18.04.1965,123-456-7899";
    char * mutable_string_literal = malloc(strlen(non_mutable_string_literal)+1);
    strcpy(mutable_string_literal, non_mutable_string_literal);

    char ** csv_line = parse_csv(mutable_string_literal, &size);

    assert(strcmp(csv_line[0], "john") == 0);
    assert(strcmp(csv_line[1], "doe") == 0);
    assert(strcmp(csv_line[2], "margaret") == 0);
    assert(strcmp(csv_line[3], "18.04.1965") == 0);
    assert(strcmp(csv_line[4], "123-456-7899") == 0);
    assert(size == 5);  // The number of values in the CSV line is put into 'size'.

    for(int i=0; i < size; i++)
        free(csv_line[i]);

    free(mutable_string_literal);
    free(csv_line);

    TTree * test_tree = init(pers);
    TPerson * jane = create(
        "Jane", 
        "Doe", 
        "Rte de Drize 8", 
        "20.05.1998", 
        "Female", 
        convert("123-456-7777")
    );
    insert(jane, test_tree);

    TPerson * steve = create(
        "Steve", 
        "Doe", 
        "Rte de Drize 9", 
        "10.05.1998", 
        "Male", 
        convert("923-456-7777")
    );
    insert(steve, test_tree);
    
    assert(strcmp(test_tree->root->right->firstname, "Steve") == 0);
    assert(strcmp(test_tree->root->left->firstname, "Jane") == 0);

    free(pers);
    free(jane);
    free(steve);
    free(test_tree);

    TTree * database = populate("./database.csv");
    
    print(database->root);
    print(database->root->left);
    print(database->root->right->right);
    
    TPerson * steven = find(database, "997-942-2546");
    assert(strcmp(steven->firstname, "Belinda") == 0);
    assert(strcmp(steven->lastname, "Rosenbaum") == 0);
    print(steven);
    
    steven = find(database, "499-517-0181");
    assert(strcmp(steven->firstname, "Gwen") == 0);
    assert(strcmp(steven->lastname, "Lind") == 0);
    print(steven);

    steven = find(database, "618-553-7922");
    assert(strcmp(steven->firstname, "Lauren") == 0);
    assert(strcmp(steven->lastname, "Hirthe") == 0);
    print(steven);
    
    return 0;
}