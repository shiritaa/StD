#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "ex1_func.h"

TTree * init(TPerson* root) {
    TTree * tree = malloc(sizeof(TTree));
    tree->root = root;
    return tree;
}

TNumber convert(char * number) 
{
    // string must be non const when using strtok()
    // beware strlen does not include \0 in size !
    char * local = malloc(strlen(number)+1);
    strcpy(local, number);

    // 2x "-" characters to exclude.
    char * parsed_number = malloc(strlen(number)+1-2);
    parsed_number[0] = '\0';
    char * curr = strtok(local, "-");
    do {
        parsed_number = strcat(parsed_number, curr);
        curr = strtok(NULL, "-");
    } while(curr != NULL);

    TNumber final = strtol(parsed_number, NULL, 10);
    free(local);
    free(parsed_number);
    return final;
}

TPerson * create(char * first, char * last, char * addr, char * bday, char * sex, TNumber num) {
    TPerson * person = (TPerson*) malloc(sizeof(TPerson));
    person->firstname = strdup(first);
    person->lastname = strdup(last);
    person->addr = strdup(addr);
    person->bday = strdup(bday);
    person->sex = strdup(sex);
    person->number = num;
    person->left = NULL;
    person->right = NULL;
    return person;
}

void insert(TPerson * new, TTree * tree) {
    TPerson * current = tree->root;
    while(current != NULL) {
        if(new->number < current->number) {
            if(current->left == NULL) {
                current->left = new;
                return;
            }
            current = current->left;
        } else {
            if(current->right == NULL) {
                current->right = new;
                return;
            }
            current = current->right;
        }
    }
}

TPerson * find(TTree * tree, char * num) {
    TNumber number = convert(num);
    TPerson * current = tree->root;
    while(current != NULL) {
        if(number == current->number) {
            return current;
        } else if(number < current->number) {
            current = current->left;
        } else {
            current = current->right;
        }
    }
    return NULL; 
}

char ** parse_csv(char * line, size_t * size) {
    char ** values = malloc(sizeof(char*) * 6);
    char * curr = strtok(line, ",");
    size_t i = 0;
    do {
        values[i] = strdup(curr);
        i++;
        curr = strtok(NULL, ",");
    } while(curr != NULL);
    *size = i;
    return values;
}

TTree * populate(char * path) 
{
    FILE * file = fopen(path, "r");
    if(file == NULL) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }
    char * lineptr = NULL;
    size_t len = 0;
    ssize_t nread;

    TTree * tree = NULL;
    while( (nread = getline(&lineptr, &len, file) ) != -1) {
        size_t size = 0;
        char ** values = parse_csv(lineptr, &size);
        TPerson * new = create(
            values[0], values[1], 
            values[2], values[3], 
            values[4], convert(values[5])
        );
        if(tree == NULL)
            tree = init(new);
        else
            insert(new, tree); // insert person into tree.
    }
    free(lineptr);
    return tree;
}

void print(TPerson* pers) {
    printf("Name: %s %s\n", pers->firstname, pers->lastname);
    printf("Address: %s\n", pers->addr);
    printf("Birthday: %s\n", pers->bday);
    printf("Sex: %s\n", pers->sex);
    printf("Number: %lu\n\n", pers->number);
}