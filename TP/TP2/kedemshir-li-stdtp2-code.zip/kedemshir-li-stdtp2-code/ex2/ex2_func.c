#include "ex2_func.h"
#include <string.h>

// Développeuse : Shir-Li Kedem

/**
 * @brief Initialise une queue vide avec malloc().
 * Ne pas oublier de free() lors de la destruction de la queue.
 * @param id
 * @return Queue * un pointeur sur une queue.
 */
Queue *initialization() {
  Queue *queue = (Queue *)malloc(sizeof(Queue));
  queue->head = NULL;
  queue->tail = NULL;
  queue->size = 0;
  return queue;
}

/**
 * @brief Ajoute un passager à la fin de la file en O(1).
 * Ne modifie pas le début de la liste excepté lors du 1er
 * appel. Modifie la fin à chaque appel.
 * @param file
 * @param id
 */
void add_element(Queue *queue, int id, char *name) {
  Passenger *new_passenger = (Passenger *)malloc(sizeof(Passenger));
  new_passenger->id = id;
  new_passenger->name = (char *)malloc(strlen(name));
  strcpy(new_passenger->name, name);
  new_passenger->next = NULL;
  if (queue->tail == NULL) {
    queue->head = new_passenger;
  } else {
    queue->tail->next = new_passenger;
  }
  queue->tail = new_passenger;
  queue->size++;
  printf("Adding passenger %s...\n", new_passenger->name);
}

/**
 * @brief Enlève le premier passager dans la queue.
 * Si la queue est vide rien n'est fait.
 * Modifie le début de la liste, pas la fin.
 * @param queue
 */
void remove_element(Queue *queue) {
  if (queue == NULL || queue->head == NULL) {
    printf("Queue is empty. Cannot remove element.\n");
    return;
  }
  Passenger *passenger_to_remove = queue->head;
  if (queue->head->next == NULL) {
    queue->head = NULL;
    queue->tail = NULL;
    queue->size--;
  } else {
    queue->head = queue->head->next;
  }
  printf("Removing ");
  print_passenger(passenger_to_remove);
  free(passenger_to_remove->name);
  free(passenger_to_remove);
}

/**
 * @brief Désalloue une queue.
 * free() tous les pointeurs alloués par malloc()
 * s'y trouvant.
 * @param queue
 */
void destroy(Queue *queue) {
  while (queue->head != NULL) {
    remove_element(queue);
  }
  free(queue);
}

/**
 * @brief Affiche un passager sans retour à la ligne.
 * Est utilisé dans print_queue().
 * @param pass
 */
void print_passenger(Passenger *pass) {
  if (pass != NULL) {
    printf("Passenger %d : %s\n", pass->id, pass->name);
  } else {
    printf("Passenger is NULL\n");
  }
}

/**
 * @brief Affiche la queue avec tous les passagers.
 * Ne fait rien si la queue est NULL ou qu'il n'y a pas
 * de passagers.
 * @param queue
 */
void print_queue(Queue *queue) {
  if (queue == NULL || queue->head == NULL) {
    return;
  }
  Passenger *current = queue->head;
  printf("\nPassengers in queue :\n");
  while (current != NULL) {
    print_passenger(current);
    current = current->next;
  }
  printf("\n");
}