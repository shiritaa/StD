#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Développeuse : Shir-Li Kedem

typedef struct Passenger Passenger;
struct Passenger {
    int id;
    char * name;
    Passenger * next;
};

typedef struct Queue Queue;
struct Queue {
    Passenger * head;
    Passenger * tail;
    int size;
};

Queue * initialization();
void add_element(Queue* queue, int id, char * name);
void remove_element(Queue* queue);
void print_queue(Queue* queue);
void print_passenger(Passenger* pass);
void destroy(Queue* queue);