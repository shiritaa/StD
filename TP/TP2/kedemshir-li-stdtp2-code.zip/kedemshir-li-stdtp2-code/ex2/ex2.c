#include "ex2_func.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

// Développeuse : Shir-Li Kedem

const int MAX_ADD = 5;
const int MAX_REM = 5;
const int MAX_SIZE = 10;

int main() {
  Queue *queue = initialization();
  printf("ESSAIS BASIQUES : \n");
  remove_element(queue);
  add_element(queue, 0, "Marchand-Maillet");
  add_element(queue, 1, "Brian Pulfer");
  add_element(queue, 2, "Hugo Haldi");
  add_element(queue, 3, "Arthur Freeman");

  print_queue(queue);
  remove_element(queue);

  print_queue(queue);
  add_element(queue, 4, "R. Stallmann");
  print_queue(queue);

  destroy(queue);

  printf("\nSIMULATION DE LA SALLE D'ATTENTE \n");

  Queue *sim_queue = initialization();
  add_element(sim_queue, 0, "Tom");
  add_element(sim_queue, 1, "Bob");
  add_element(sim_queue, 2, "Harry");
  add_element(sim_queue, 3, "McQueen");

  int i = 0;
  while (1) {
    printf("Round %d \n", i);
    i++;

    // retirer passagers
    int n_rem = rand() % MAX_REM + 1;
    for (int j = 0; j < n_rem; j++) {
      remove_element(sim_queue);
    }
    print_queue(sim_queue);
    usleep(3000000); // arrête le programme pendant 3 secondes.

    // ajouter passagers
    int n_add = rand() % MAX_ADD + 1;
    for (int j = 0; j < n_add; j++) {
      char name[20];
      int id = 0;
      if (sim_queue->tail != NULL) {
        id = sim_queue->tail->id + 1;
      }
      sprintf(name, "Passenger %d", id);
      add_el#include "ex2_func.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

const int MAX_ADD = 5;
const int MAX_REM = 5;
const int MAX_SIZE = 10;

int main() {
  Queue *queue = initialization();
  printf("ESSAIS BASIQUES : \n");
  remove_element(queue);
  add_element(queue, 0, "Marchand-Maillet");
  add_element(queue, 1, "Brian Pulfer");
  add_element(queue, 2, "Hugo Haldi");
  add_element(queue, 3, "Arthur Freeman");

  print_queue(queue);
  remove_element(queue);

  print_queue(queue);
  add_element(queue, 4, "R. Stallmann");
  print_queue(queue);

  destroy(queue);

  printf("\nSIMULATION DE LA SALLE D'ATTENTE \n");

  Queue *sim_queue = initialization();
  add_element(sim_queue, 0, "Tom");
  add_element(sim_queue, 1, "Bob");
  add_element(sim_queue, 2, "Harry");
  add_element(sim_queue, 3, "McQueen");

  int i = 0;
  while (1) {
    printf("Round %d \n", i);
    i++;

    // retirer passagers
    int n_rem = rand() % MAX_REM + 1;
    for (int j = 0; j < n_rem; j++) {
      remove_element(sim_queue);
    }
    
    print_queue(sim_queue);
    usleep(3000000); // arrête le programme pendant 3 secondes.

      // ajouter passagers
    int randomMax = 0;
    int remaining_place = 10 - queue->size;
    if (remaining_place > MAX_ADD) {
      randomMax = MAX_ADD;
    } else {
      randomMax = remaining_place;
    }
    int n_add = rand() % randomMax + 1;
    for (int j = 0; j < n_add; j++) {
      char name[20];
      int id = 0;
      if (sim_queue->tail != NULL) {
        id = sim_queue->tail->id + 1;
      }
      sprintf(name, "Person %d", id);
      add_element(sim_queue, id, name);
    }
    print_queue(sim_queue);
    usleep(3000000); // u => microsecondes.
  }
  return 0;
}ement(sim_queue, id, name);
    }
    print_queue(sim_queue);
    usleep(3000000); // u => microsecondes.
  }

  return 0;
}