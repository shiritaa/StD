#include <string.h>
#include "ex1_func.h"

// Développeuse : Shir-Li Kedem

/**
 * @brief Initialise une task.
 */
Task* make_task(char * name, char ** steps, size_t n_steps){
    Task *task = malloc(sizeof(Task));
    task->name = strdup(name);
    task->steps = malloc(n_steps * sizeof(char*));
    for (size_t i = 0; i < n_steps; i++) {
        task->steps[i] = strdup(steps[i]);
    }
    task->n_steps = n_steps;
    return task;
}


/**
 * @brief Initialise une pile vide.
 * @param stack pointeur vers une pile. 
 */
void init(Stack* stack){
    stack->tasks = NULL;
    stack->n_tasks = 0;
}

/**
 * @brief ajoute un element sur la pile
 * modifie le pointeur sur le sommet de pile
 * e.g. TStack * stack.
 * @returns void
*/
void push(Stack* stack, Task* task) {
    stack->n_tasks++;
    stack->tasks = realloc(stack->tasks, stack->n_tasks * sizeof(Task *));
    stack->tasks[stack->n_tasks - 1] = task;
}

/**
 * @brief supprime le sommet de la pile et renvoie un pointeur vers lui. 
 * @returns NULL if stack has no elements or stack is NULL.
 */
Task* pop(Stack *stack) {
    if (stack->n_tasks == 0) {
        return NULL;
    }
    Task *task = stack->tasks[stack->n_tasks - 1];
    stack->n_tasks--;
    stack->tasks = realloc(stack->tasks, stack->n_tasks * sizeof(Task *));
    return task;
}

/**
 * @brief Affiche une task.
 * 
 * @param task 
 */
void print_task(Task * task) {
    if (task != NULL) {
        printf("Task name : %s\n", task->name);
        for (int i = 0; i < task->n_steps; i++) {
            printf("Step %d : %s\n", i + 1, task->steps[i]);
        }
    } else {
    printf("Task is NULL\n");
    }

}

/**
 * @brief Affiche les elements empilées.
 * @param stack pointeur vers une pile d'elements.
 * Ne fait rien si la pile est vide.
 */
void print_stack(Stack * stack) {
    if (stack->n_tasks == 0) {
        printf("Stack is empty\n");
        return;
    }
    for (int i = 0; i < stack->n_tasks; i++) {
        printf("\nTask %d : \n", i + 1);
        print_task(stack->tasks[i]);
    }

}

/**
 * @brief Passe la checklist en revue et demande à l'utilisateur
 * de confirmer les tâches une par une.
 * @param stack une liste de Sous-Catégories à valider.
 */
void validate_checklist(Stack *stack) {
  for (int task_i = stack->n_tasks - 1; task_i >= 0; task_i--) {
    if (stack->tasks[task_i] != NULL) {
      printf("\nTask : %s\n", stack->tasks[task_i]->name);
      int yes;
      do {
        yes = 1;
        int nb_step = stack->tasks[task_i]->n_steps;
        for (int step_i = 0; step_i < nb_step && yes == 1; step_i++) {
          printf("Step : %s\n", stack->tasks[task_i]->steps[step_i]);
          printf("Do you want to confirm this step?\nEnter 1 for 'Yes' or 0 "
                 "for 'No'.\n");
          scanf("%d", &yes);

          if (yes == 1) {
            if (step_i + 1 == stack->tasks[task_i]->n_steps) {
              pop(stack);
            }
          } else if (yes != 0) {
            printf("Invalid value. Please enter 1 or 0.\n");
            yes = 0;
          }
        }
      } while (yes != 1);
    } else {
      printf("Task %d is NULL\n", task_i);
    }
  }
}