#include "ex1_func.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  Stack *stack;
  stack = (Stack *)malloc(sizeof(Stack));

  init(stack);

  // il faut empiler à l'envers !
  char *steps3[] = {"Verification Intégrité structurelle",
                    "Verification alignement des ailerons",
                    "Vérification Essence"};
  Task *task3 = make_task("Verification Fuselage", steps3, 3);

  char *steps2[] = {"Verification bouton C", "Verification bouton D"};
  Task *task2 = make_task("Verification Poste Co-Pilote", steps2, 2);

  char *steps1[] = {"Verification bouton A", "Verification bouton B"};
  Task *task1 = make_task("Verification Poste Pilote", steps1, 2);

  push(stack, task3);
  push(stack, task2);
  push(stack, task1);

  printf("Etat de la checklist :\n");
  print_stack(stack);

  validate_checklist(stack);

  print_stack(stack); // Après validation, la pile doit être vide.
  return 0;
}
