#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Développeuse : Shir-Li Kedem

typedef struct Task Task;
struct Task {
  char *name;
  char **steps;
  size_t n_steps;
};

typedef struct Stack {
  Task **tasks;
  int n_tasks;
} Stack;

Task *make_task(char *name, char **steps, size_t n_steps);
void init(Stack *stack);
void push(Stack *stack, Task *task);
Task *pop(Stack *stack);
void print_stack(Stack *stack);
void print_task(Task *element);

void validate_checklist(Stack *stack);