#include "ex3_func.h"
#include <stdio.h>
#include <stdlib.h>

// Développeuse : Shir-Li Kedem

Person * create_person(char* firstname, char * lastname) {
    Person * person = (Person*) malloc(sizeof(Person));
    person->firstname = firstname;
    person->lastname = lastname;
    return person;
}

Car * create_car(char* brand, int top_speed){
    Car * car = (Car*) malloc(sizeof(Car));
    car->brand = brand;
    car->top_speed = top_speed;
    return car;
}

List * create_list() {
    List * list = (List*) malloc(sizeof(List));
    list->first = NULL;
    list->size = 0;
    return list;
}

Element* create_element(void * content, typeOf type){
    Element* element = (Element*) malloc(sizeof(Element));
    element->next = NULL;
    element->content = content;
    element->type = type;
    return element;
}

Element * get_element(List* list, int index){
    if (index >= list->size || index < 0) {
        return NULL;
    }
    int i = list->size - 1;
    Element * element = list->first;
    while (i != index) {
        element = element->next;
        i--;
    }
    return element;
}


int idx_of(List* list, Element * element){
    int index = 0;
    Element * current = list->first;
    while (current != NULL && current != element) {
        index++;
        current = current->next;
    }
    if (current == NULL) {
        return -1;
    }
    return index;
}


void push(List* list, Element* elem) {
    elem->next = NULL;
    if (list->size == 0) {
        list->first = elem;
    } else {
        Element * last = list->first;
        while (last->next != NULL) {
            last = last->next;
        }
        last->next = elem;
    }
    list->size++;
}


Element * pop(List* list){
    if (list->size == 0) {
        return NULL;
    }
    Element * elem = list->first;
    if (list->size == 1) {
        list->first = NULL;
    } else {
        Element *prev = list->first;
        while (elem->next != NULL) {
            prev = elem;
            elem = elem->next;
        }
        prev->next = NULL;
    }
    list->size--;
    elem->next = NULL;
    return elem;
}


void print_list(List * list) {
    Element * current = list->first;
    printf("=============================\n");
    while (current != NULL) {
        if (current->type == person) {
            Person * person = (Person*) current->content;
            printf("Firstname : %s, Lastname : %s\n", person->firstname, person->lastname);
        }
        else if (current->type == car) {
            Car * car = (Car*) current->content;
            printf("Brand : %s, Top speed : %d\n", car->brand, car->top_speed);
        }
      current = current->next;
    }
}
