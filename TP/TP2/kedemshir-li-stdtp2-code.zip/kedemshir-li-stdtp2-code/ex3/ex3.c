#include <stdio.h>
#include "ex3_func.h"

int main() {
    printf("-------------------LISTE AVEC DES PERSONNES-------------------\n\n");
    Person* person1 = create_person("Stephane", "Maillet");
    Person* person2 = create_person("Bryan", "Pulfer");
    Person* person3 = create_person("Arthur", "Freeman");
    
    // Remarque: Pourquoi on donne un (void*) a cette fonction, et pas un (Persone*) ?
    Element* element1 = create_element((void*) person1, person);  
    Element* element2 = create_element((void*) person2, person);
    Element* element3 = create_element((void*) person3, person);
    
    List * list = create_list();

    push(list, element1);
    push(list, element2);
    print_list(list);

    person2->firstname = "Brian";
    push(list, element3);
    print_list(list);

    printf("\n\n\n\n-------------------LISTE AVEC DES VOITURES-------------------\n\n");
    
    Car* car1 = create_car("VW Polo", 200);
    Car* car2 = create_car("Tesla model 3", 10);
    Car* car3 = create_car("Renault Megane", 1200);
    
    Element* element1p = create_element((void*) car1, car); 
    Element* element2p = create_element((void*) car2, car);
    Element* element3p = create_element((void*) car3, car);
    
    List * liste = create_list();

    push(liste, element1p);
    push(liste, element2p);
    print_list(liste);

    car1->brand = "Volkswagen Polo";

    push(liste, element3p);
    print_list(liste);

    printf("\n\n\n\n-------------------LISTE HETEROGENE-------------------\n\n");
    List * polymorphic_list = create_list();

    push(polymorphic_list, element1);
    push(polymorphic_list, element1p);
    push(polymorphic_list, element2);
    push(polymorphic_list, element2p);
    push(polymorphic_list, element3);
    push(polymorphic_list, element3p);

    print_list(polymorphic_list);

    int idx_brian = idx_of(polymorphic_list, element2);
    if (idx_brian >= 0){
        printf("Brian est dans index %d (position %d) dans la liste\n", idx_brian, idx_brian+1);
    } else{
        printf("Brian n'est pas dans la liste\n");
    }

    return 0;
}

/*
                        OUTPUT ATTENDU
-------------------LISTE AVEC DES PERSONNES-------------------

=============================
Firstname : Stephane, Lastname : Maillet
Firstname : Bryan, Lastname : Pulfer
=============================
Firstname : Stephane, Lastname : Maillet
Firstname : Brian, Lastname : Pulfer
Firstname : Arthur, Lastname : Freeman

-------------------LISTE AVEC DES VOITURES-------------------

=============================
Brand : VW Polo, Top Speed : 200
Brand : Tesla model 3, Top Speed : 10
=============================
Brand : Volkswagen Polo, Top Speed : 200
Brand : Tesla model 3, Top Speed : 10
Brand : Renault Megane, Top Speed : 1200

-------------------LISTE HETEROGENE-------------------

=============================
Firstname : Stephane, Lastname : Maillet
Brand : Volkswagen Polo, Top Speed : 200
Firstname : Brian, Lastname : Pulfer
Brand : Tesla model 3, Top Speed : 10
Firstname : Arthur, Lastname : Freeman
Brand : Renault Megane, Top Speed : 1200
Brian est dans index 2 (position 3) dans la liste
*/