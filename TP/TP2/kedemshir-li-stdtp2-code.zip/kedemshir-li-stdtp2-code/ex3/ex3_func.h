
// Développeuse : Shir-Li Kedem

typedef struct Person Person;
struct Person {
    char * lastname;
    char* firstname;
};

typedef struct Car Car;
struct Car {
    int top_speed;
    char * brand;
};

typedef enum {person, car} typeOf;

typedef struct element Element; // Remarque: Pourquoi faisons-nous cela?
struct element{
    Element* next;
    typeOf type;
    void* content;
};

typedef struct List List;
struct List {
    Element* first;
    int size;
};

Person * create_person(char*, char*);
Car * create_car(char*, int);
List * create_list();
Element * create_element(void*, typeOf);
Element * get_element(List*, int);

int idx_of(List*, Element*);
void push(List*, Element*);
Element * pop(List*);
void print_list(List*);
